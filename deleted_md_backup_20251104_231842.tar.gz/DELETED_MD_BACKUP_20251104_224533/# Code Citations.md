# Code Citations

## License: unknown
https://github.com/stephanediondev/readerself/tree/476e013ac87360c203af275033609058f39a5ce4/application/helpers/readerself_helper.php

```
$latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000) {
       $latFrom = deg2rad($latitudeFrom);
       $lonFrom = deg2rad($longitudeFrom);
       $latTo = deg2rad($latitudeTo);
       $lonTo = deg2rad($longitudeTo);
       $
```


## License: MIT
https://github.com/jimwins/scat/tree/2c6d080dfc68f3801c37e3b3af82f9f6770e8295/lib/Scat/Distance.php

```
= deg2rad($latitudeTo);
       $lonTo = deg2rad($longitudeTo);
       $latDelta = $latTo - $latFrom;
       $lonDelta = $lonTo - $lonFrom;
       $angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2)
```


## License: unknown
https://github.com/jrmdesigns/foodsaver/tree/88860f3c0e91c826951407df3447ff30048cb240/filtersearch.php

```
latitudeTo, $longitudeTo, $earthRadius = 6371000) {
       $latFrom = deg2rad($latitudeFrom);
       $lonFrom = deg2rad($longitudeFrom);
       $latTo = deg2rad($latitudeTo);
       $lonTo = deg2rad($longitudeTo);
       $latDelta = $latTo - $latFrom
```


## License: MIT
https://github.com/shah77pc/finallavarel/tree/13cc44f2b5f904fdcba87f8ec98d88ad6fccb405/app/Http/Controllers/OrderController.php

```
) {
       $latFrom = deg2rad($latitudeFrom);
       $lonFrom = deg2rad($longitudeFrom);
       $latTo = deg2rad($latitudeTo);
       $lonTo = deg2rad($longitudeTo);
       $latDelta = $latTo - $latFrom;
       $lonDelta = $lonTo - $lonFrom
```


## License: unknown
https://github.com/welsonoktario/depo-air/tree/46f30e3088fc7e2bffb6824baf9ec924ba473aa3/app/Http/Controllers/API/TransaksiController.php

```
= deg2rad($latitudeFrom);
       $lonFrom = deg2rad($longitudeFrom);
       $latTo = deg2rad($latitudeTo);
       $lonTo = deg2rad($longitudeTo);
       $latDelta = $latTo - $latFrom;
       $lonDelta = $lonTo - $lonFrom;
       $angle =
```

