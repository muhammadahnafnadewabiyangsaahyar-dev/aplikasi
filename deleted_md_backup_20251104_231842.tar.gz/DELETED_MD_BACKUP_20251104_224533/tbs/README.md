# TinyButStrong template engine

www.tinybutstrong.com

TBS is a PHP template engine for pro and beginners.
Only 1 class with few methods and properties, but it can do may things for any text templates, including HTML and XML.
The only engine that enables W3C compliant templates.
It has many plugins, including OpenTBS for merging LibreOffice and Ms Office documents.

## Documentation

For documentation see 
www.tinybutstrong.com/manual.php

## Licence

TinyButStrong is released under the LGPL (Lesser General Public Licence) version 3.0.

## Distribution repository

TinyButStrong in on GitHub since version 3.5.3.

TinyButStrong versions 3.10.1 or later can be installed with [Composer](http://getcomposer.org/download/).

The package is "tinybutstrong/tinybutstrong" 
